﻿/// <reference path="../bower_components/angular/angular.min.js" />
var sample = angular.module('sample', [])
    .controller('mainController', function ($scope, utility) {

        (function () {
            $scope.configJson = utility.getJsonData();
            angular.forEach($scope.configJson, function (item) {
                if (item.type == 3) {
                    $scope[item.model] = item[item.model];
                    $scope[item.model + "options"] = item.options
                } else {
                    $scope[item.model] = item[item.model];
                }
            });
        })();

        $scope.onClickMe = function () {
            debugger;
        }

    })
    .factory('utility', function ($q, $window) {
        return {
            setRequiredAttribute: function (item) {
                return item.validation.required == "true"?'required':''
            },
            replaceIt: function (find, replace, str) {
                return str.replace(new RegExp(find, 'g'), replace);
            },
            setMaxLengthAttribute: function (item) {
                return item.validation.hasOwnProperty('maxFieldLength') ? 'maxlength = "' + item.validation.maxFieldLength + '"' : '';
            },
            setMinAttribute: function (item) {
                return item.validation.hasOwnProperty('minField') ? 'min = "' + item.validation.minField + '"' : '';
            },
            setMaxAttribute: function (item) {
                return item.validation.hasOwnProperty('maxField') ? 'max = "' + item.validation.maxField + '"' : '';
            },
            getJsonData: function () {
                return $window.configJson.config;
            },
            generateHTML: function (config) {
                var itemFrom = '';
                var utility = this;
                angular.forEach(config, function (item) {
                    console.log(item);
                    switch (item.type) {
                        case 1:
                            itemFrom += '<span><input type="text" ng-model="' + item.model + '"  ' + utility.setRequiredAttribute(item) + '  ' + utility.setMaxLengthAttribute(item) + ' /></span>';
                            break;
                        case 2:
                            itemFrom += '<span><input type="datetime-local" ng-model="' + item.model + '"  ' + utility.setRequiredAttribute(item) + ' /></span>';
                            break;
                        case 3:
                            var dropdownstring = '<span><select name="repeatSelect" ng-model="selectedCity">';
                            dropdownstring += '<option ng-repeat="option in options" value="{{option.id}}">{{option.name}}</option>';
                            dropdownstring += '</select><span>';
                            dropdownstring = utility.replaceIt('options', item.model + "options", dropdownstring);
                            itemFrom += dropdownstring;
                            break;
                        case 4:
                            itemFrom += '<span><input type="number" ng-model="' + item.model + '"  ' + utility.setRequiredAttribute(item) + '  ' + utility.setMinAttribute(item) + '  ' + utility.setMaxAttribute(item) + '/></span>';
                            break;
                    }
                })
                return itemFrom;
            }

        }
    })
    .directive('gRenderer', function ($compile,utility) {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                config:'='
            },
            link: function (scope, element, attr) {
                element.html(utility.generateHTML(scope.config));
                $compile(element.contents())(scope.$parent);
            }
        }
    });